import type { CropRegion, MediaEdit } from './types';
export declare const MAX_CLIP_SECONDS = 60;
export declare const clamp: (n: number, low: number, high: number) => number;
export declare function coverCrop(width: number, height: number): CropRegion;
export declare function zoomCrop(crop: CropRegion, factor: number, width: number, height: number): CropRegion;
export declare function moveCrop(crop: CropRegion, dx: number, dy: number): CropRegion;
export declare function setEditDuration(edit: MediaEdit, duration: number, max: number): MediaEdit;
export declare const floorTenth: (n: number) => number;
