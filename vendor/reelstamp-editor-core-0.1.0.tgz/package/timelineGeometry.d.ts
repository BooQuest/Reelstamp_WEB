export declare const SELECTION_FRACTION = 0.75;
export declare const SELECTION_INSET: number;
export declare function maxSegmentStart(sourceDuration: number, duration: number): number;
export declare function clampSegmentStart(value: number, sourceDuration: number, duration: number): number;
export declare function timelinePosition(time: number, start: number, duration: number): number;
export declare function timelineWindow(start: number, duration: number, sourceDuration: number): {
    start: number;
    end: number;
};
export declare function timelineTicks(start: number, duration: number, sourceDuration: number): number[];
