const nt = 0.6, et = 2.2, ot = 0.5, rt = 0.95, it = 5, at = 60, _t = 450, ct = 800, st = 2, It = 0.97, Tt = 0.3, At = 10, Ot = "RECOMMENDED", Et = "FORCED", Ct = 60, S = "CAPTION_RENDER_V1", Nt = 0.85, Pt = 1080, Rt = 1920, xt = 408, U = 2.6470588235294117, c = (t) => Math.round(t * U * 1e3) / 1e3, g = c(28), X = 1.25, y = Math.round(g * X * 1e3) / 1e3, C = "ReelstampCaptionPretendard", H = 600, N = "#FFFFFF", P = "#000000", m = 1, M = c(16), D = c(8), f = c(18), w = Math.round(
  1080 * 0.85
), B = c(8), V = c(20), Y = "rgba(0,0,0,0.28)", k = "pre-wrap", z = "break-word", v = "normal", G = "auto", dt = c(28), lt = c(12), ht = c(10), l = {
  whiteSpace: "pre",
  xRatio: 0.5,
  yRatio: 0.12,
  scale: 1,
  boxed: !0,
  styleVersion: S,
  maxWidthRatio: 0.85,
  maxLines: null
}, Z = {
  ...l,
  whiteSpace: "pre-wrap",
  yRatio: 0.82,
  maxLines: 2,
  anchorY: "BOTTOM"
}, K = 60, I = (t, n, e) => Math.max(n, Math.min(e, t));
function $(t, n) {
  const e = Math.min(1, 0.5625 * n / t), r = Math.min(1, 16 / 9 * t / n);
  return { x: (1 - e) / 2, y: (1 - r) / 2, width: e, height: r };
}
function ut(t, n, e, r) {
  const o = $(e, r), _ = I(t.width / n, o.width / 4, o.width), i = _ * e / r * 16 / 9;
  return {
    x: I(t.x + (t.width - _) / 2, 0, 1 - _),
    y: I(t.y + (t.height - i) / 2, 0, 1 - i),
    width: _,
    height: i
  };
}
function pt(t, n, e) {
  return {
    ...t,
    x: I(t.x + n, 0, 1 - t.width),
    y: I(t.y + e, 0, 1 - t.height)
  };
}
function mt(t, n, e) {
  const r = Math.min(F(e), K);
  if (!Number.isFinite(n) || n < 0.1 || n > r || Math.abs(n * 10 - Math.round(n * 10)) > 1e-6)
    throw new Error(
      `0.1초부터 ${r.toFixed(1)}초까지 0.1초 단위로 입력해 주세요.`
    );
  return {
    ...t,
    duration: n,
    start: I(t.start, 0, Math.max(0, e - n))
  };
}
const F = (t) => Math.floor((t + 1e-8) * 10) / 10, h = 0.75, j = (1 - h) / 2;
function J(t, n) {
  return Math.max(0, F(t - n));
}
function Mt(t, n, e) {
  return I(
    Math.round(t * 10) / 10,
    0,
    J(n, e)
  );
}
function Dt(t, n, e) {
  return (j + (t - n) / e * h) * 100;
}
function q(t, n, e) {
  const r = (n / h - n) / 2;
  return {
    start: Math.max(0, t - r),
    end: Math.min(e, t + n + r)
  };
}
function ft(t, n, e) {
  const r = q(t, n, e), o = Math.max(1, Math.round(n * 10 / 3)), _ = [];
  for (let i = Math.ceil(r.start * 10 / o) * o; i <= r.end * 10; i += o)
    _.push(i / 10);
  return _;
}
function u(t) {
  if (t.styleVersion !== "CAPTION_RENDER_V2") return H;
  const n = t.fontWeight;
  return typeof n == "number" && Number.isFinite(n) && n >= 100 && n <= 900 ? n : t.textPreset === "bold" ? 700 : 600;
}
const St = [
  "#FFFFFF",
  "#000000",
  "#EF4444",
  "#FACC15",
  "#22C55E",
  "#3B82F6",
  "#A855F7",
  "#EC4899"
];
function R(t, n) {
  const e = t.styleVersion === "CAPTION_RENDER_V2", r = n.textPreset === "basic" ? 400 : n.textPreset === "bold" ? 700 : void 0;
  return {
    ...t,
    styleVersion: "CAPTION_RENDER_V2",
    fontFamily: e && t.fontFamily || C,
    fontWeight: u(t),
    textColor: e && t.textColor || N,
    textAlign: e && t.textAlign || "center",
    textPreset: e && t.textPreset || "basic",
    boxBackgroundColor: e && t.boxBackgroundColor || P,
    boxBackgroundOpacity: e ? t.boxBackgroundOpacity ?? 1 : 1,
    ...n,
    ...r == null || n.fontWeight !== void 0 ? {} : { fontWeight: r }
  };
}
function gt(t) {
  const n = R(t, {});
  return {
    fontFamily: n.fontFamily,
    fontWeight: n.fontWeight,
    color: n.textColor,
    textAlign: n.textAlign,
    textShadow: n.textPreset === "shadow" ? "0.04em 0.04em 0.08em #000000" : "none"
  };
}
function Ft(t) {
  const n = t.boxBackgroundColor === "#FFFFFF" ? "255,255,255" : "0,0,0";
  return t.boxed ? `rgba(${n},${t.boxBackgroundOpacity ?? 1})` : "transparent";
}
const Q = () => typeof crypto < "u" && typeof crypto.randomUUID == "function" ? crypto.randomUUID() : `caption-${Date.now()}-${Math.random().toString(36).slice(2)}`, E = (t, n, e) => Math.min(e, Math.max(n, t)), L = (t, n = {}) => {
  const e = (t ?? "").replace(/\r\n/g, `
`).replace(/\r/g, `
`);
  return !n.restoreEscapedNewlines || e.includes(`
`) ? e : e.replace(/\\n/g, `
`);
}, b = (t) => ({
  ...t,
  xRatio: E(t.xRatio, 0, 1),
  yRatio: E(t.yRatio, 0, 1),
  scale: E(t.scale, 0.6, 2.2),
  boxed: t.boxed !== !1,
  styleVersion: t.styleVersion === "CAPTION_RENDER_V2" ? "CAPTION_RENDER_V2" : S,
  maxWidthRatio: E(
    typeof t.maxWidthRatio == "number" ? t.maxWidthRatio : 0.85,
    0.5,
    0.95
  ),
  maxLines: typeof t.maxLines == "number" && Number.isFinite(t.maxLines) ? Math.max(1, Math.round(t.maxLines)) : null,
  anchorY: t.anchorY === "BOTTOM" ? "BOTTOM" : "CENTER"
}), d = (t) => {
  const n = b(t);
  return {
    ...n,
    renderWidth: 1080,
    renderHeight: 1920,
    fontFamily: t.styleVersion === "CAPTION_RENDER_V2" && t.fontFamily || C,
    fontWeight: u(t),
    textAlign: t.styleVersion === "CAPTION_RENDER_V2" && t.textAlign || "center",
    fontSizePx: g,
    lineHeightPx: y,
    textColor: t.styleVersion === "CAPTION_RENDER_V2" ? t.textColor ?? N : N,
    maxWidthPx: w,
    boxBackgroundColor: t.styleVersion === "CAPTION_RENDER_V2" ? t.boxBackgroundColor ?? P : P,
    boxBackgroundOpacity: t.styleVersion === "CAPTION_RENDER_V2" ? t.boxBackgroundOpacity ?? m : m,
    boxPaddingXPx: M,
    boxPaddingYPx: D,
    boxBorderRadiusPx: f,
    paddingXPx: M,
    paddingYPx: D,
    borderRadiusPx: f,
    shadowOffsetYPx: B,
    shadowBlurPx: V,
    shadowColor: Y,
    whiteSpace: t.whiteSpace ?? k,
    overflowWrap: z,
    wordBreak: v,
    lineBreak: G,
    anchorY: n.anchorY
  };
}, Lt = (t, n, e, r = !0) => JSON.stringify({
  projectName: t.trim(),
  activeClipOrder: n,
  captionsEnabled: r,
  captionItems: e.map((o) => ({
    ...o,
    text: L(o.text)
  })).filter((o) => o.text.trim().length > 0).map((o) => ({
    id: o.id,
    text: o.text,
    source: o.source,
    role: o.role,
    placement: o.placement,
    zIndex: o.zIndex,
    style: d(o.style)
  }))
}), bt = (t) => (t ?? []).map((n) => {
  const e = n.source ?? "USER", r = e === "AUTO" ? "SPEECH" : "OVERLAY";
  let o = b({
    ...e === "AUTO" ? Z : l,
    ...n.style ?? {},
    whiteSpace: e === "AUTO" ? "pre-wrap" : "pre"
  });
  return e === "TEMPLATE" && (o.styleVersion !== "CAPTION_RENDER_V2" || (o.textPreset ?? "basic") === "basic" && u(o) === 600) && (o = R(o, { textPreset: "basic" })), {
    ...n,
    text: L(n.text, {
      restoreEscapedNewlines: !0
    }),
    source: e,
    role: r,
    style: o
  };
}), tt = (t) => [...t].sort((n, e) => n.zIndex - e.zIndex);
function Wt(t, n, e, r, o) {
  const _ = r ? e / (2 * n.height) : 0, i = (t.xRatio - 0.5) * n.width, T = (t.yRatio - _ - 0.5) * n.height, s = {
    x: o.x ? Math.abs(i) < 12 - 1e-7 : Math.abs(i) <= 6 + 1e-7,
    y: o.y ? Math.abs(T) < 12 - 1e-7 : Math.abs(T) <= 6 + 1e-7
  }, O = s.y ? 0.5 + _ : t.yRatio;
  return O > 1 && (s.y = !1), {
    xRatio: Math.max(0, Math.min(1, s.x ? 0.5 : t.xRatio)),
    yRatio: Math.max(0, Math.min(1, s.y ? O : t.yRatio)),
    guides: s
  };
}
function Ut(t, n) {
  const e = t.find((i) => i.id === n);
  if (!e || e.source === "AUTO" || e.placement.type !== "CLIP" || !e.text.trim())
    return null;
  const r = e.placement.clipId, o = t.filter(
    (i) => i.placement.type === "CLIP" && i.placement.clipId === r
  );
  if (o.filter((i) => i.source !== "AUTO").length >= 5)
    return null;
  const _ = (i) => Math.max(0, Math.min(1, i + (i + 0.02 > 1 ? -0.02 : 0.02)));
  return {
    ...e,
    id: Q(),
    source: "USER",
    role: "OVERLAY",
    placement: { ...e.placement },
    zIndex: Math.max(0, ...o.map((i) => i.zIndex)) + 1,
    style: {
      ...R(e.style, {}),
      xRatio: _(e.style.xRatio),
      yRatio: _(e.style.yRatio)
    }
  };
}
function Xt(t, n, e) {
  const r = t.find((a) => a.id === n);
  if (!r || r.source === "AUTO" || r.placement.type !== "CLIP")
    return t;
  const o = r.placement.clipId, _ = t.filter(
    (a) => a.placement.type === "CLIP" && a.placement.clipId === o
  ), i = tt(
    _.filter((a) => a.source !== "AUTO")
  ), T = i.findIndex((a) => a.id === n), s = e === "front" ? i.length - 1 : e === "back" ? 0 : Math.max(
    0,
    Math.min(
      i.length - 1,
      T + (e === "forward" ? 1 : -1)
    )
  );
  if (T === s) return t;
  const O = new Set(
    _.filter((a) => a.source === "AUTO").map((a) => a.zIndex)
  );
  let p = -1 / 0;
  const W = i.map((a) => {
    let A = Math.max(Math.trunc(a.zIndex), p + 1);
    for (; O.has(A); ) A++;
    return p = A, A;
  });
  i.splice(T, 1), i.splice(s, 0, r);
  const x = new Map(i.map((a, A) => [a.id, W[A]]));
  return t.map(
    (a) => x.has(a.id) && a.zIndex !== x.get(a.id) ? { ...a, zIndex: x.get(a.id) } : a
  );
}
function yt(t) {
  const n = R(
    {
      ...l,
      xRatio: t.xRatio,
      yRatio: t.yRatio,
      scale: t.scale,
      anchorY: t.anchorY
    },
    { textPreset: "basic", fontWeight: 400, whiteSpace: "pre" }
  ), e = d(t), r = d(n);
  return [.../* @__PURE__ */ new Set([...Object.keys(e), ...Object.keys(r)])].every(
    (_) => e[_] === r[_]
  ) ? t : n;
}
export {
  Z as AUTO_CAPTION_DEFAULT_STYLE,
  st as AUTO_CAPTION_MAX_LINES,
  ct as AUTO_CAPTION_MIN_DISPLAY_MS,
  _t as AUTO_CAPTION_PAUSE_SPLIT_MS,
  It as AUTO_CAPTION_WIDTH_SAFETY_RATIO,
  g as CAPTION_BASE_FONT_SIZE_PX,
  P as CAPTION_BOX_BACKGROUND_COLOR,
  m as CAPTION_BOX_BACKGROUND_OPACITY,
  f as CAPTION_BOX_BORDER_RADIUS_PX,
  M as CAPTION_BOX_PADDING_X_PX,
  D as CAPTION_BOX_PADDING_Y_PX,
  C as CAPTION_FONT_FAMILY,
  H as CAPTION_FONT_WEIGHT,
  xt as CAPTION_LAYOUT_REFERENCE_WIDTH,
  G as CAPTION_LINE_BREAK,
  X as CAPTION_LINE_HEIGHT,
  y as CAPTION_LINE_HEIGHT_PX,
  w as CAPTION_MAX_WIDTH_PX,
  z as CAPTION_OVERFLOW_WRAP,
  U as CAPTION_REFERENCE_TO_RENDER_SCALE,
  Rt as CAPTION_RENDER_HEIGHT,
  Pt as CAPTION_RENDER_WIDTH,
  ht as CAPTION_RESIZE_HANDLE_FONT_SIZE_PX,
  lt as CAPTION_RESIZE_HANDLE_OFFSET_PX,
  dt as CAPTION_RESIZE_HANDLE_SIZE_PX,
  V as CAPTION_SHADOW_BLUR_PX,
  Y as CAPTION_SHADOW_COLOR,
  B as CAPTION_SHADOW_OFFSET_Y_PX,
  S as CAPTION_STYLE_VERSION_RENDER_V1,
  N as CAPTION_TEXT_COLOR,
  k as CAPTION_WHITE_SPACE,
  v as CAPTION_WORD_BREAK,
  Nt as DEFAULT_CAPTION_MAX_WIDTH_RATIO,
  l as DEFAULT_CAPTION_STYLE,
  Et as DURATION_MODE_FORCED,
  Ot as DURATION_MODE_RECOMMENDED,
  at as MAX_AUTO_CAPTION_CHUNKS_PER_CLIP,
  it as MAX_CAPTIONS_PER_CLIP,
  rt as MAX_CAPTION_MAX_WIDTH_RATIO,
  et as MAX_CAPTION_SCALE,
  K as MAX_CLIP_SECONDS,
  ot as MIN_CAPTION_MAX_WIDTH_RATIO,
  nt as MIN_CAPTION_SCALE,
  Tt as MIN_TRIM_DURATION_SECONDS,
  Ct as RECOMMENDED_AUTO_STOP_SECONDS,
  h as SELECTION_FRACTION,
  j as SELECTION_INSET,
  St as TEXT_COLORS,
  At as TIMELINE_THUMBNAIL_COUNT,
  d as buildCaptionExportStyle,
  Lt as buildDraftSignature,
  Ft as captionBackground,
  gt as captionTextStyle,
  I as clamp,
  Mt as clampSegmentStart,
  E as clampValue,
  $ as coverCrop,
  Q as createCaptionId,
  Ut as duplicateCaption,
  F as floorTenth,
  J as maxSegmentStart,
  pt as moveCrop,
  b as normalizeCaptionStyle,
  L as normalizeCaptionText,
  bt as normalizeSessionCaptions,
  Xt as reorderCaption,
  yt as resetCaptionStyle,
  u as resolveCaptionFontWeight,
  mt as setEditDuration,
  Wt as snapCaptionCenter,
  tt as sortCaptions,
  Dt as timelinePosition,
  ft as timelineTicks,
  q as timelineWindow,
  c as toCaptionRenderPx,
  R as withGalleryStyle,
  ut as zoomCrop
};
