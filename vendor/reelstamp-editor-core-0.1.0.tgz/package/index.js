const y = 0.6, G = 2.2, z = 0.5, Z = 0.95, K = 5, $ = 60, v = 450, j = 800, J = 2, q = 0.97, Q = 0.3, tt = 10, nt = "RECOMMENDED", ot = "FORCED", _t = 60, R = "CAPTION_RENDER_V1", et = 0.85, rt = 1080, Tt = 1920, Ot = 408, F = 2.6470588235294117, r = (t) => Math.round(t * F * 1e3) / 1e3, x = r(28), M = 1.25, h = Math.round(x * M * 1e3) / 1e3, E = "ReelstampCaptionPretendard", S = 600, N = "#FFFFFF", i = "#000000", c = 1, C = r(16), s = r(8), P = r(18), l = Math.round(
  1080 * 0.85
), L = r(8), f = r(20), X = "rgba(0,0,0,0.28)", p = "pre-wrap", H = "break-word", g = "normal", U = "auto", At = r(28), at = r(12), It = r(10), Et = r(140), d = {
  xRatio: 0.5,
  yRatio: 0.12,
  scale: 1,
  boxed: !0,
  styleVersion: R,
  maxWidthRatio: 0.85,
  maxLines: null
}, W = {
  ...d,
  yRatio: 0.82,
  maxLines: 2,
  anchorY: "BOTTOM"
}, b = 60, A = (t, n, o) => Math.max(n, Math.min(o, t));
function B(t, n) {
  const o = Math.min(1, 0.5625 * n / t), e = Math.min(1, 16 / 9 * t / n);
  return { x: (1 - o) / 2, y: (1 - e) / 2, width: o, height: e };
}
function Nt(t, n, o, e) {
  const _ = B(o, e), T = A(t.width / n, _.width / 4, _.width), O = T * o / e * 16 / 9;
  return {
    x: A(t.x + (t.width - T) / 2, 0, 1 - T),
    y: A(t.y + (t.height - O) / 2, 0, 1 - O),
    width: T,
    height: O
  };
}
function it(t, n, o) {
  return {
    ...t,
    x: A(t.x + n, 0, 1 - t.width),
    y: A(t.y + o, 0, 1 - t.height)
  };
}
function ct(t, n, o) {
  const e = Math.min(D(o), b);
  if (!Number.isFinite(n) || n < 0.1 || n > e || Math.abs(n * 10 - Math.round(n * 10)) > 1e-6)
    throw new Error(
      `0.1초부터 ${e.toFixed(1)}초까지 0.1초 단위로 입력해 주세요.`
    );
  return {
    ...t,
    duration: n,
    start: A(t.start, 0, Math.max(0, o - n))
  };
}
const D = (t) => Math.floor((t + 1e-8) * 10) / 10, I = 0.75, w = (1 - I) / 2;
function V(t, n) {
  return Math.max(0, D(t - n));
}
function Ct(t, n, o) {
  return A(Math.round(t * 10) / 10, 0, V(n, o));
}
function st(t, n, o) {
  return (w + (t - n) / o * I) * 100;
}
function Y(t, n, o) {
  const e = (n / I - n) / 2;
  return {
    start: Math.max(0, t - e),
    end: Math.min(o, t + n + e)
  };
}
function Pt(t, n, o) {
  const e = Y(t, n, o), _ = Math.max(1, Math.round(n * 10 / 3)), T = [];
  for (let O = Math.ceil(e.start * 10 / _) * _; O <= e.end * 10; O += _)
    T.push(O / 10);
  return T;
}
const Rt = () => typeof crypto < "u" && typeof crypto.randomUUID == "function" ? crypto.randomUUID() : `caption-${Date.now()}-${Math.random().toString(36).slice(2)}`, a = (t, n, o) => Math.min(o, Math.max(n, t)), m = (t, n = {}) => {
  const o = (t ?? "").replace(/\r\n/g, `
`).replace(/\r/g, `
`);
  return !n.restoreEscapedNewlines || o.includes(`
`) ? o : o.replace(/\\n/g, `
`);
}, u = (t) => ({
  ...t,
  xRatio: a(t.xRatio, 0, 1),
  yRatio: a(t.yRatio, 0, 1),
  scale: a(t.scale, 0.6, 2.2),
  boxed: t.boxed !== !1,
  styleVersion: t.styleVersion === "CAPTION_RENDER_V2" ? "CAPTION_RENDER_V2" : R,
  maxWidthRatio: a(
    typeof t.maxWidthRatio == "number" ? t.maxWidthRatio : 0.85,
    0.5,
    0.95
  ),
  maxLines: typeof t.maxLines == "number" && Number.isFinite(t.maxLines) ? Math.max(1, Math.round(t.maxLines)) : null,
  anchorY: t.anchorY === "BOTTOM" ? "BOTTOM" : "CENTER"
}), k = (t) => {
  const n = u(t);
  return {
    ...n,
    renderWidth: 1080,
    renderHeight: 1920,
    fontFamily: t.styleVersion === "CAPTION_RENDER_V2" && t.fontFamily || E,
    fontWeight: t.styleVersion === "CAPTION_RENDER_V2" && t.textPreset === "bold" ? 700 : S,
    fontSizePx: x,
    lineHeightPx: h,
    textColor: t.styleVersion === "CAPTION_RENDER_V2" ? t.textColor ?? N : N,
    maxWidthPx: l,
    boxBackgroundColor: t.styleVersion === "CAPTION_RENDER_V2" ? t.boxBackgroundColor ?? i : i,
    boxBackgroundOpacity: t.styleVersion === "CAPTION_RENDER_V2" ? t.boxBackgroundOpacity ?? c : c,
    boxPaddingXPx: C,
    boxPaddingYPx: s,
    boxBorderRadiusPx: P,
    paddingXPx: C,
    paddingYPx: s,
    borderRadiusPx: P,
    shadowOffsetYPx: L,
    shadowBlurPx: f,
    shadowColor: X,
    whiteSpace: p,
    overflowWrap: H,
    wordBreak: g,
    lineBreak: U,
    anchorY: n.anchorY
  };
}, xt = (t, n, o, e = !0) => JSON.stringify({
  projectName: t.trim(),
  activeClipOrder: n,
  captionsEnabled: e,
  captionItems: o.map((_) => ({
    ..._,
    text: m(_.text)
  })).filter((_) => _.text.trim().length > 0).map((_) => ({
    id: _.id,
    text: _.text,
    source: _.source,
    role: _.role,
    placement: _.placement,
    zIndex: _.zIndex,
    style: k(_.style)
  }))
}), dt = (t) => (t ?? []).map((n) => {
  const o = n.source ?? "USER", e = o === "AUTO" ? "SPEECH" : "OVERLAY";
  return {
    ...n,
    text: m(n.text, {
      restoreEscapedNewlines: !0
    }),
    source: o,
    role: e,
    style: u(
      o === "AUTO" ? { ...W, ...n.style ?? {} } : { ...d, ...n.style ?? {} }
    )
  };
}), Dt = [
  "#FFFFFF",
  "#000000",
  "#EF4444",
  "#FACC15",
  "#22C55E",
  "#3B82F6",
  "#A855F7",
  "#EC4899"
];
function mt(t, n) {
  return {
    ...t,
    styleVersion: "CAPTION_RENDER_V2",
    fontFamily: t.fontFamily || "ReelstampCaptionPretendard",
    textColor: t.textColor || "#FFFFFF",
    textAlign: t.textAlign || "center",
    textPreset: t.textPreset || "basic",
    boxBackgroundColor: t.boxBackgroundColor || "#000000",
    boxBackgroundOpacity: t.boxBackgroundOpacity ?? 1,
    ...n
  };
}
function ut(t) {
  return t.styleVersion !== "CAPTION_RENDER_V2" ? {} : {
    fontFamily: t.fontFamily || "ReelstampCaptionPretendard",
    fontWeight: t.textPreset === "bold" ? 700 : 600,
    color: t.textColor || "#FFFFFF",
    textAlign: t.textAlign || "center",
    textShadow: t.textPreset === "shadow" ? "0.04em 0.04em 0.08em #000000" : "none"
  };
}
function Ft(t) {
  const n = t.boxBackgroundColor === "#FFFFFF" ? "255,255,255" : "0,0,0";
  return t.boxed ? `rgba(${n},${t.boxBackgroundOpacity ?? 1})` : "transparent";
}
export {
  W as AUTO_CAPTION_DEFAULT_STYLE,
  J as AUTO_CAPTION_MAX_LINES,
  j as AUTO_CAPTION_MIN_DISPLAY_MS,
  v as AUTO_CAPTION_PAUSE_SPLIT_MS,
  q as AUTO_CAPTION_WIDTH_SAFETY_RATIO,
  x as CAPTION_BASE_FONT_SIZE_PX,
  i as CAPTION_BOX_BACKGROUND_COLOR,
  c as CAPTION_BOX_BACKGROUND_OPACITY,
  P as CAPTION_BOX_BORDER_RADIUS_PX,
  C as CAPTION_BOX_PADDING_X_PX,
  s as CAPTION_BOX_PADDING_Y_PX,
  E as CAPTION_FONT_FAMILY,
  S as CAPTION_FONT_WEIGHT,
  Et as CAPTION_INPUT_MIN_WIDTH_PX,
  Ot as CAPTION_LAYOUT_REFERENCE_WIDTH,
  U as CAPTION_LINE_BREAK,
  M as CAPTION_LINE_HEIGHT,
  h as CAPTION_LINE_HEIGHT_PX,
  l as CAPTION_MAX_WIDTH_PX,
  H as CAPTION_OVERFLOW_WRAP,
  F as CAPTION_REFERENCE_TO_RENDER_SCALE,
  Tt as CAPTION_RENDER_HEIGHT,
  rt as CAPTION_RENDER_WIDTH,
  It as CAPTION_RESIZE_HANDLE_FONT_SIZE_PX,
  at as CAPTION_RESIZE_HANDLE_OFFSET_PX,
  At as CAPTION_RESIZE_HANDLE_SIZE_PX,
  f as CAPTION_SHADOW_BLUR_PX,
  X as CAPTION_SHADOW_COLOR,
  L as CAPTION_SHADOW_OFFSET_Y_PX,
  R as CAPTION_STYLE_VERSION_RENDER_V1,
  N as CAPTION_TEXT_COLOR,
  p as CAPTION_WHITE_SPACE,
  g as CAPTION_WORD_BREAK,
  et as DEFAULT_CAPTION_MAX_WIDTH_RATIO,
  d as DEFAULT_CAPTION_STYLE,
  ot as DURATION_MODE_FORCED,
  nt as DURATION_MODE_RECOMMENDED,
  $ as MAX_AUTO_CAPTION_CHUNKS_PER_CLIP,
  K as MAX_CAPTIONS_PER_CLIP,
  Z as MAX_CAPTION_MAX_WIDTH_RATIO,
  G as MAX_CAPTION_SCALE,
  b as MAX_CLIP_SECONDS,
  z as MIN_CAPTION_MAX_WIDTH_RATIO,
  y as MIN_CAPTION_SCALE,
  Q as MIN_TRIM_DURATION_SECONDS,
  _t as RECOMMENDED_AUTO_STOP_SECONDS,
  I as SELECTION_FRACTION,
  w as SELECTION_INSET,
  Dt as TEXT_COLORS,
  tt as TIMELINE_THUMBNAIL_COUNT,
  k as buildCaptionExportStyle,
  xt as buildDraftSignature,
  Ft as captionBackground,
  ut as captionTextStyle,
  A as clamp,
  Ct as clampSegmentStart,
  a as clampValue,
  B as coverCrop,
  Rt as createCaptionId,
  D as floorTenth,
  V as maxSegmentStart,
  it as moveCrop,
  u as normalizeCaptionStyle,
  m as normalizeCaptionText,
  dt as normalizeSessionCaptions,
  ct as setEditDuration,
  st as timelinePosition,
  Pt as timelineTicks,
  Y as timelineWindow,
  r as toCaptionRenderPx,
  mt as withGalleryStyle,
  Nt as zoomCrop
};
