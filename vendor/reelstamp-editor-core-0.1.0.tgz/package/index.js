const z = 0.6, v = 2.2, Z = 0.5, K = 0.95, $ = 5, j = 60, J = 450, q = 800, Q = 2, tt = 0.97, nt = 0.3, ot = 10, et = "RECOMMENDED", _t = "FORCED", rt = 60, x = "CAPTION_RENDER_V1", it = 0.85, Tt = 1080, At = 1920, Ot = 408, l = 2.6470588235294117, r = (t) => Math.round(t * l * 1e3) / 1e3, D = r(28), S = 1.25, F = Math.round(D * S * 1e3) / 1e3, a = "ReelstampCaptionPretendard", f = 600, E = "#FFFFFF", I = "#000000", N = 1, C = r(16), P = r(8), R = r(18), L = Math.round(
  1080 * 0.85
), g = r(8), W = r(20), b = "rgba(0,0,0,0.28)", X = "pre-wrap", p = "break-word", H = "normal", U = "auto", at = r(28), Et = r(12), It = r(10), d = {
  xRatio: 0.5,
  yRatio: 0.12,
  scale: 1,
  boxed: !0,
  styleVersion: x,
  maxWidthRatio: 0.85,
  maxLines: null
}, B = {
  ...d,
  yRatio: 0.82,
  maxLines: 2,
  anchorY: "BOTTOM"
}, V = 60, A = (t, n, o) => Math.max(n, Math.min(o, t));
function w(t, n) {
  const o = Math.min(1, 0.5625 * n / t), _ = Math.min(1, 16 / 9 * t / n);
  return { x: (1 - o) / 2, y: (1 - _) / 2, width: o, height: _ };
}
function ct(t, n, o, _) {
  const e = w(o, _), i = A(t.width / n, e.width / 4, e.width), T = i * o / _ * 16 / 9;
  return {
    x: A(t.x + (t.width - i) / 2, 0, 1 - i),
    y: A(t.y + (t.height - T) / 2, 0, 1 - T),
    width: i,
    height: T
  };
}
function st(t, n, o) {
  return {
    ...t,
    x: A(t.x + n, 0, 1 - t.width),
    y: A(t.y + o, 0, 1 - t.height)
  };
}
function Nt(t, n, o) {
  const _ = Math.min(u(o), V);
  if (!Number.isFinite(n) || n < 0.1 || n > _ || Math.abs(n * 10 - Math.round(n * 10)) > 1e-6)
    throw new Error(
      `0.1초부터 ${_.toFixed(1)}초까지 0.1초 단위로 입력해 주세요.`
    );
  return {
    ...t,
    duration: n,
    start: A(t.start, 0, Math.max(0, o - n))
  };
}
const u = (t) => Math.floor((t + 1e-8) * 10) / 10, c = 0.75, Y = (1 - c) / 2;
function k(t, n) {
  return Math.max(0, u(t - n));
}
function Ct(t, n, o) {
  return A(
    Math.round(t * 10) / 10,
    0,
    k(n, o)
  );
}
function Pt(t, n, o) {
  return (Y + (t - n) / o * c) * 100;
}
function y(t, n, o) {
  const _ = (n / c - n) / 2;
  return {
    start: Math.max(0, t - _),
    end: Math.min(o, t + n + _)
  };
}
function Rt(t, n, o) {
  const _ = y(t, n, o), e = Math.max(1, Math.round(n * 10 / 3)), i = [];
  for (let T = Math.ceil(_.start * 10 / e) * e; T <= _.end * 10; T += e)
    i.push(T / 10);
  return i;
}
function s(t) {
  if (t.styleVersion !== "CAPTION_RENDER_V2") return f;
  const n = t.fontWeight;
  return typeof n == "number" && Number.isFinite(n) && n >= 100 && n <= 900 ? n : t.textPreset === "bold" ? 700 : 600;
}
const xt = [
  "#FFFFFF",
  "#000000",
  "#EF4444",
  "#FACC15",
  "#22C55E",
  "#3B82F6",
  "#A855F7",
  "#EC4899"
];
function m(t, n) {
  const o = t.styleVersion === "CAPTION_RENDER_V2", _ = n.textPreset === "basic" ? 400 : n.textPreset === "bold" ? 700 : n.textPreset === "shadow" ? 600 : void 0;
  return {
    ...t,
    styleVersion: "CAPTION_RENDER_V2",
    fontFamily: o && t.fontFamily || a,
    fontWeight: s(t),
    textColor: o && t.textColor || E,
    textAlign: o && t.textAlign || "center",
    textPreset: o && t.textPreset || "basic",
    boxBackgroundColor: o && t.boxBackgroundColor || I,
    boxBackgroundOpacity: o ? t.boxBackgroundOpacity ?? 1 : 1,
    ...n,
    ..._ == null ? {} : { fontWeight: _ }
  };
}
function Dt(t) {
  const n = m(t, {});
  return {
    fontFamily: n.fontFamily,
    fontWeight: n.fontWeight,
    color: n.textColor,
    textAlign: n.textAlign,
    textShadow: n.textPreset === "shadow" ? "0.04em 0.04em 0.08em #000000" : "none"
  };
}
function dt(t) {
  const n = t.boxBackgroundColor === "#FFFFFF" ? "255,255,255" : "0,0,0";
  return t.boxed ? `rgba(${n},${t.boxBackgroundOpacity ?? 1})` : "transparent";
}
const ut = () => typeof crypto < "u" && typeof crypto.randomUUID == "function" ? crypto.randomUUID() : `caption-${Date.now()}-${Math.random().toString(36).slice(2)}`, O = (t, n, o) => Math.min(o, Math.max(n, t)), h = (t, n = {}) => {
  const o = (t ?? "").replace(/\r\n/g, `
`).replace(/\r/g, `
`);
  return !n.restoreEscapedNewlines || o.includes(`
`) ? o : o.replace(/\\n/g, `
`);
}, M = (t) => ({
  ...t,
  xRatio: O(t.xRatio, 0, 1),
  yRatio: O(t.yRatio, 0, 1),
  scale: O(t.scale, 0.6, 2.2),
  boxed: t.boxed !== !1,
  styleVersion: t.styleVersion === "CAPTION_RENDER_V2" ? "CAPTION_RENDER_V2" : x,
  maxWidthRatio: O(
    typeof t.maxWidthRatio == "number" ? t.maxWidthRatio : 0.85,
    0.5,
    0.95
  ),
  maxLines: typeof t.maxLines == "number" && Number.isFinite(t.maxLines) ? Math.max(1, Math.round(t.maxLines)) : null,
  anchorY: t.anchorY === "BOTTOM" ? "BOTTOM" : "CENTER"
}), G = (t) => {
  const n = M(t);
  return {
    ...n,
    renderWidth: 1080,
    renderHeight: 1920,
    fontFamily: t.styleVersion === "CAPTION_RENDER_V2" && t.fontFamily || a,
    fontWeight: s(t),
    textAlign: t.styleVersion === "CAPTION_RENDER_V2" && t.textAlign || "center",
    fontSizePx: D,
    lineHeightPx: F,
    textColor: t.styleVersion === "CAPTION_RENDER_V2" ? t.textColor ?? E : E,
    maxWidthPx: L,
    boxBackgroundColor: t.styleVersion === "CAPTION_RENDER_V2" ? t.boxBackgroundColor ?? I : I,
    boxBackgroundOpacity: t.styleVersion === "CAPTION_RENDER_V2" ? t.boxBackgroundOpacity ?? N : N,
    boxPaddingXPx: C,
    boxPaddingYPx: P,
    boxBorderRadiusPx: R,
    paddingXPx: C,
    paddingYPx: P,
    borderRadiusPx: R,
    shadowOffsetYPx: g,
    shadowBlurPx: W,
    shadowColor: b,
    whiteSpace: X,
    overflowWrap: p,
    wordBreak: H,
    lineBreak: U,
    anchorY: n.anchorY
  };
}, mt = (t, n, o, _ = !0) => JSON.stringify({
  projectName: t.trim(),
  activeClipOrder: n,
  captionsEnabled: _,
  captionItems: o.map((e) => ({
    ...e,
    text: h(e.text)
  })).filter((e) => e.text.trim().length > 0).map((e) => ({
    id: e.id,
    text: e.text,
    source: e.source,
    role: e.role,
    placement: e.placement,
    zIndex: e.zIndex,
    style: G(e.style)
  }))
}), ht = (t) => (t ?? []).map((n) => {
  const o = n.source ?? "USER", _ = o === "AUTO" ? "SPEECH" : "OVERLAY";
  let e = M({
    ...o === "AUTO" ? B : d,
    ...n.style ?? {}
  });
  return o === "TEMPLATE" && (e.styleVersion !== "CAPTION_RENDER_V2" || (e.textPreset ?? "basic") === "basic" && s(e) === 600) && (e = m(e, { textPreset: "basic" })), {
    ...n,
    text: h(n.text, {
      restoreEscapedNewlines: !0
    }),
    source: o,
    role: _,
    style: e
  };
});
export {
  B as AUTO_CAPTION_DEFAULT_STYLE,
  Q as AUTO_CAPTION_MAX_LINES,
  q as AUTO_CAPTION_MIN_DISPLAY_MS,
  J as AUTO_CAPTION_PAUSE_SPLIT_MS,
  tt as AUTO_CAPTION_WIDTH_SAFETY_RATIO,
  D as CAPTION_BASE_FONT_SIZE_PX,
  I as CAPTION_BOX_BACKGROUND_COLOR,
  N as CAPTION_BOX_BACKGROUND_OPACITY,
  R as CAPTION_BOX_BORDER_RADIUS_PX,
  C as CAPTION_BOX_PADDING_X_PX,
  P as CAPTION_BOX_PADDING_Y_PX,
  a as CAPTION_FONT_FAMILY,
  f as CAPTION_FONT_WEIGHT,
  Ot as CAPTION_LAYOUT_REFERENCE_WIDTH,
  U as CAPTION_LINE_BREAK,
  S as CAPTION_LINE_HEIGHT,
  F as CAPTION_LINE_HEIGHT_PX,
  L as CAPTION_MAX_WIDTH_PX,
  p as CAPTION_OVERFLOW_WRAP,
  l as CAPTION_REFERENCE_TO_RENDER_SCALE,
  At as CAPTION_RENDER_HEIGHT,
  Tt as CAPTION_RENDER_WIDTH,
  It as CAPTION_RESIZE_HANDLE_FONT_SIZE_PX,
  Et as CAPTION_RESIZE_HANDLE_OFFSET_PX,
  at as CAPTION_RESIZE_HANDLE_SIZE_PX,
  W as CAPTION_SHADOW_BLUR_PX,
  b as CAPTION_SHADOW_COLOR,
  g as CAPTION_SHADOW_OFFSET_Y_PX,
  x as CAPTION_STYLE_VERSION_RENDER_V1,
  E as CAPTION_TEXT_COLOR,
  X as CAPTION_WHITE_SPACE,
  H as CAPTION_WORD_BREAK,
  it as DEFAULT_CAPTION_MAX_WIDTH_RATIO,
  d as DEFAULT_CAPTION_STYLE,
  _t as DURATION_MODE_FORCED,
  et as DURATION_MODE_RECOMMENDED,
  j as MAX_AUTO_CAPTION_CHUNKS_PER_CLIP,
  $ as MAX_CAPTIONS_PER_CLIP,
  K as MAX_CAPTION_MAX_WIDTH_RATIO,
  v as MAX_CAPTION_SCALE,
  V as MAX_CLIP_SECONDS,
  Z as MIN_CAPTION_MAX_WIDTH_RATIO,
  z as MIN_CAPTION_SCALE,
  nt as MIN_TRIM_DURATION_SECONDS,
  rt as RECOMMENDED_AUTO_STOP_SECONDS,
  c as SELECTION_FRACTION,
  Y as SELECTION_INSET,
  xt as TEXT_COLORS,
  ot as TIMELINE_THUMBNAIL_COUNT,
  G as buildCaptionExportStyle,
  mt as buildDraftSignature,
  dt as captionBackground,
  Dt as captionTextStyle,
  A as clamp,
  Ct as clampSegmentStart,
  O as clampValue,
  w as coverCrop,
  ut as createCaptionId,
  u as floorTenth,
  k as maxSegmentStart,
  st as moveCrop,
  M as normalizeCaptionStyle,
  h as normalizeCaptionText,
  ht as normalizeSessionCaptions,
  s as resolveCaptionFontWeight,
  Nt as setEditDuration,
  Pt as timelinePosition,
  Rt as timelineTicks,
  y as timelineWindow,
  r as toCaptionRenderPx,
  m as withGalleryStyle,
  ct as zoomCrop
};
