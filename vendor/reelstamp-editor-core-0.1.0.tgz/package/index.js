const z = 0.6, v = 2.2, Z = 0.5, K = 0.95, $ = 5, j = 60, J = 450, q = 800, Q = 2, tt = 0.97, nt = 0.3, ot = 10, et = "RECOMMENDED", _t = "FORCED", rt = 60, R = "CAPTION_RENDER_V1", Tt = 0.85, it = 1080, At = 1920, Ot = 408, M = 2.6470588235294117, r = (t) => Math.round(t * M * 1e3) / 1e3, x = r(28), l = 1.25, S = Math.round(x * l * 1e3) / 1e3, a = "ReelstampCaptionPretendard", F = 600, I = "#FFFFFF", E = "#000000", N = 1, s = r(16), C = r(8), P = r(18), f = Math.round(
  1080 * 0.85
), L = r(8), g = r(20), W = "rgba(0,0,0,0.28)", X = "pre-wrap", p = "break-word", H = "normal", b = "auto", at = r(28), It = r(12), Et = r(10), D = {
  xRatio: 0.5,
  yRatio: 0.12,
  scale: 1,
  boxed: !0,
  styleVersion: R,
  maxWidthRatio: 0.85,
  maxLines: null
}, U = {
  ...D,
  yRatio: 0.82,
  maxLines: 2,
  anchorY: "BOTTOM"
}, B = 60, A = (t, n, o) => Math.max(n, Math.min(o, t));
function w(t, n) {
  const o = Math.min(1, 0.5625 * n / t), e = Math.min(1, 16 / 9 * t / n);
  return { x: (1 - o) / 2, y: (1 - e) / 2, width: o, height: e };
}
function ct(t, n, o, e) {
  const _ = w(o, e), T = A(t.width / n, _.width / 4, _.width), i = T * o / e * 16 / 9;
  return {
    x: A(t.x + (t.width - T) / 2, 0, 1 - T),
    y: A(t.y + (t.height - i) / 2, 0, 1 - i),
    width: T,
    height: i
  };
}
function Nt(t, n, o) {
  return {
    ...t,
    x: A(t.x + n, 0, 1 - t.width),
    y: A(t.y + o, 0, 1 - t.height)
  };
}
function st(t, n, o) {
  const e = Math.min(d(o), B);
  if (!Number.isFinite(n) || n < 0.1 || n > e || Math.abs(n * 10 - Math.round(n * 10)) > 1e-6)
    throw new Error(
      `0.1초부터 ${e.toFixed(1)}초까지 0.1초 단위로 입력해 주세요.`
    );
  return {
    ...t,
    duration: n,
    start: A(t.start, 0, Math.max(0, o - n))
  };
}
const d = (t) => Math.floor((t + 1e-8) * 10) / 10, c = 0.75, V = (1 - c) / 2;
function Y(t, n) {
  return Math.max(0, d(t - n));
}
function Ct(t, n, o) {
  return A(
    Math.round(t * 10) / 10,
    0,
    Y(n, o)
  );
}
function Pt(t, n, o) {
  return (V + (t - n) / o * c) * 100;
}
function k(t, n, o) {
  const e = (n / c - n) / 2;
  return {
    start: Math.max(0, t - e),
    end: Math.min(o, t + n + e)
  };
}
function Rt(t, n, o) {
  const e = k(t, n, o), _ = Math.max(1, Math.round(n * 10 / 3)), T = [];
  for (let i = Math.ceil(e.start * 10 / _) * _; i <= e.end * 10; i += _)
    T.push(i / 10);
  return T;
}
function u(t) {
  if (t.styleVersion !== "CAPTION_RENDER_V2") return F;
  const n = t.fontWeight;
  return typeof n == "number" && Number.isFinite(n) && n >= 100 && n <= 900 ? n : t.textPreset === "bold" ? 700 : 600;
}
const xt = [
  "#FFFFFF",
  "#000000",
  "#EF4444",
  "#FACC15",
  "#22C55E",
  "#3B82F6",
  "#A855F7",
  "#EC4899"
];
function y(t, n) {
  const o = t.styleVersion === "CAPTION_RENDER_V2", e = n.textPreset === "basic" ? 400 : n.textPreset === "bold" ? 700 : n.textPreset === "shadow" ? 600 : void 0;
  return {
    ...t,
    styleVersion: "CAPTION_RENDER_V2",
    fontFamily: o && t.fontFamily || a,
    fontWeight: u(t),
    textColor: o && t.textColor || I,
    textAlign: o && t.textAlign || "center",
    textPreset: o && t.textPreset || "basic",
    boxBackgroundColor: o && t.boxBackgroundColor || E,
    boxBackgroundOpacity: o ? t.boxBackgroundOpacity ?? 1 : 1,
    ...n,
    ...e == null ? {} : { fontWeight: e }
  };
}
function Dt(t) {
  const n = y(t, {});
  return {
    fontFamily: n.fontFamily,
    fontWeight: n.fontWeight,
    color: n.textColor,
    textAlign: n.textAlign,
    textShadow: n.textPreset === "shadow" ? "0.04em 0.04em 0.08em #000000" : "none"
  };
}
function dt(t) {
  const n = t.boxBackgroundColor === "#FFFFFF" ? "255,255,255" : "0,0,0";
  return t.boxed ? `rgba(${n},${t.boxBackgroundOpacity ?? 1})` : "transparent";
}
const ut = () => typeof crypto < "u" && typeof crypto.randomUUID == "function" ? crypto.randomUUID() : `caption-${Date.now()}-${Math.random().toString(36).slice(2)}`, O = (t, n, o) => Math.min(o, Math.max(n, t)), m = (t, n = {}) => {
  const o = (t ?? "").replace(/\r\n/g, `
`).replace(/\r/g, `
`);
  return !n.restoreEscapedNewlines || o.includes(`
`) ? o : o.replace(/\\n/g, `
`);
}, h = (t) => ({
  ...t,
  xRatio: O(t.xRatio, 0, 1),
  yRatio: O(t.yRatio, 0, 1),
  scale: O(t.scale, 0.6, 2.2),
  boxed: t.boxed !== !1,
  styleVersion: t.styleVersion === "CAPTION_RENDER_V2" ? "CAPTION_RENDER_V2" : R,
  maxWidthRatio: O(
    typeof t.maxWidthRatio == "number" ? t.maxWidthRatio : 0.85,
    0.5,
    0.95
  ),
  maxLines: typeof t.maxLines == "number" && Number.isFinite(t.maxLines) ? Math.max(1, Math.round(t.maxLines)) : null,
  anchorY: t.anchorY === "BOTTOM" ? "BOTTOM" : "CENTER"
}), G = (t) => {
  const n = h(t);
  return {
    ...n,
    renderWidth: 1080,
    renderHeight: 1920,
    fontFamily: t.styleVersion === "CAPTION_RENDER_V2" && t.fontFamily || a,
    fontWeight: u(t),
    textAlign: t.styleVersion === "CAPTION_RENDER_V2" && t.textAlign || "center",
    fontSizePx: x,
    lineHeightPx: S,
    textColor: t.styleVersion === "CAPTION_RENDER_V2" ? t.textColor ?? I : I,
    maxWidthPx: f,
    boxBackgroundColor: t.styleVersion === "CAPTION_RENDER_V2" ? t.boxBackgroundColor ?? E : E,
    boxBackgroundOpacity: t.styleVersion === "CAPTION_RENDER_V2" ? t.boxBackgroundOpacity ?? N : N,
    boxPaddingXPx: s,
    boxPaddingYPx: C,
    boxBorderRadiusPx: P,
    paddingXPx: s,
    paddingYPx: C,
    borderRadiusPx: P,
    shadowOffsetYPx: L,
    shadowBlurPx: g,
    shadowColor: W,
    whiteSpace: X,
    overflowWrap: p,
    wordBreak: H,
    lineBreak: b,
    anchorY: n.anchorY
  };
}, mt = (t, n, o, e = !0) => JSON.stringify({
  projectName: t.trim(),
  activeClipOrder: n,
  captionsEnabled: e,
  captionItems: o.map((_) => ({
    ..._,
    text: m(_.text)
  })).filter((_) => _.text.trim().length > 0).map((_) => ({
    id: _.id,
    text: _.text,
    source: _.source,
    role: _.role,
    placement: _.placement,
    zIndex: _.zIndex,
    style: G(_.style)
  }))
}), ht = (t) => (t ?? []).map((n) => {
  const o = n.source ?? "USER", e = o === "AUTO" ? "SPEECH" : "OVERLAY";
  return {
    ...n,
    text: m(n.text, {
      restoreEscapedNewlines: !0
    }),
    source: o,
    role: e,
    style: h(
      o === "AUTO" ? { ...U, ...n.style ?? {} } : { ...D, ...n.style ?? {} }
    )
  };
});
export {
  U as AUTO_CAPTION_DEFAULT_STYLE,
  Q as AUTO_CAPTION_MAX_LINES,
  q as AUTO_CAPTION_MIN_DISPLAY_MS,
  J as AUTO_CAPTION_PAUSE_SPLIT_MS,
  tt as AUTO_CAPTION_WIDTH_SAFETY_RATIO,
  x as CAPTION_BASE_FONT_SIZE_PX,
  E as CAPTION_BOX_BACKGROUND_COLOR,
  N as CAPTION_BOX_BACKGROUND_OPACITY,
  P as CAPTION_BOX_BORDER_RADIUS_PX,
  s as CAPTION_BOX_PADDING_X_PX,
  C as CAPTION_BOX_PADDING_Y_PX,
  a as CAPTION_FONT_FAMILY,
  F as CAPTION_FONT_WEIGHT,
  Ot as CAPTION_LAYOUT_REFERENCE_WIDTH,
  b as CAPTION_LINE_BREAK,
  l as CAPTION_LINE_HEIGHT,
  S as CAPTION_LINE_HEIGHT_PX,
  f as CAPTION_MAX_WIDTH_PX,
  p as CAPTION_OVERFLOW_WRAP,
  M as CAPTION_REFERENCE_TO_RENDER_SCALE,
  At as CAPTION_RENDER_HEIGHT,
  it as CAPTION_RENDER_WIDTH,
  Et as CAPTION_RESIZE_HANDLE_FONT_SIZE_PX,
  It as CAPTION_RESIZE_HANDLE_OFFSET_PX,
  at as CAPTION_RESIZE_HANDLE_SIZE_PX,
  g as CAPTION_SHADOW_BLUR_PX,
  W as CAPTION_SHADOW_COLOR,
  L as CAPTION_SHADOW_OFFSET_Y_PX,
  R as CAPTION_STYLE_VERSION_RENDER_V1,
  I as CAPTION_TEXT_COLOR,
  X as CAPTION_WHITE_SPACE,
  H as CAPTION_WORD_BREAK,
  Tt as DEFAULT_CAPTION_MAX_WIDTH_RATIO,
  D as DEFAULT_CAPTION_STYLE,
  _t as DURATION_MODE_FORCED,
  et as DURATION_MODE_RECOMMENDED,
  j as MAX_AUTO_CAPTION_CHUNKS_PER_CLIP,
  $ as MAX_CAPTIONS_PER_CLIP,
  K as MAX_CAPTION_MAX_WIDTH_RATIO,
  v as MAX_CAPTION_SCALE,
  B as MAX_CLIP_SECONDS,
  Z as MIN_CAPTION_MAX_WIDTH_RATIO,
  z as MIN_CAPTION_SCALE,
  nt as MIN_TRIM_DURATION_SECONDS,
  rt as RECOMMENDED_AUTO_STOP_SECONDS,
  c as SELECTION_FRACTION,
  V as SELECTION_INSET,
  xt as TEXT_COLORS,
  ot as TIMELINE_THUMBNAIL_COUNT,
  G as buildCaptionExportStyle,
  mt as buildDraftSignature,
  dt as captionBackground,
  Dt as captionTextStyle,
  A as clamp,
  Ct as clampSegmentStart,
  O as clampValue,
  w as coverCrop,
  ut as createCaptionId,
  d as floorTenth,
  Y as maxSegmentStart,
  Nt as moveCrop,
  h as normalizeCaptionStyle,
  m as normalizeCaptionText,
  ht as normalizeSessionCaptions,
  u as resolveCaptionFontWeight,
  st as setEditDuration,
  Pt as timelinePosition,
  Rt as timelineTicks,
  k as timelineWindow,
  r as toCaptionRenderPx,
  y as withGalleryStyle,
  ct as zoomCrop
};
