import type { CaptionItem, CaptionStyle } from "./types";
export type CaptionOrderAction = "forward" | "backward" | "front" | "back";
export type CaptionGuides = {
    x: boolean;
    y: boolean;
};
/** Stable sort: equal legacy indices keep their input order, including in the renderer. */
export declare const sortCaptions: (items: CaptionItem[]) => CaptionItem[];
export declare function snapCaptionCenter(raw: {
    xRatio: number;
    yRatio: number;
}, frame: {
    width: number;
    height: number;
}, boxHeight: number, anchorBottom: boolean, previous: CaptionGuides): {
    xRatio: number;
    yRatio: number;
    guides: {
        x: boolean;
        y: boolean;
    };
};
export declare function duplicateCaption(items: CaptionItem[], id: string): CaptionItem | null;
export declare function reorderCaption(items: CaptionItem[], id: string, action: CaptionOrderAction): CaptionItem[];
export declare function resetCaptionStyle(style: CaptionStyle): CaptionStyle;
