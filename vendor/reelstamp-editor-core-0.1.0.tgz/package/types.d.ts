export type CaptionStyleVersion = "WEB_BOX_V2" | "CAPTION_RENDER_V1" | "CAPTION_RENDER_V2";
export type CaptionStyle = {
    textAlign?: "left" | "center" | "right";
    textPreset?: "basic" | "bold" | "shadow";
    xRatio: number;
    yRatio: number;
    scale: number;
    boxed: boolean;
    styleVersion?: CaptionStyleVersion;
    maxWidthRatio?: number;
    maxLines?: number | null;
    renderWidth?: number;
    renderHeight?: number;
    layoutWidth?: number;
    layoutHeight?: number;
    baseFontSizePx?: number;
    lineHeight?: number;
    fontFamily?: string;
    fontWeight?: number;
    fontSizePx?: number;
    lineHeightPx?: number;
    textColor?: string;
    maxWidthPx?: number;
    boxBackgroundColor?: string;
    boxBackgroundOpacity?: number;
    boxPaddingXPx?: number;
    boxPaddingYPx?: number;
    boxBorderRadiusPx?: number;
    paddingXPx?: number;
    paddingYPx?: number;
    borderRadiusPx?: number;
    shadowOffsetYPx?: number;
    shadowBlurPx?: number;
    shadowColor?: string;
    whiteSpace?: "pre-wrap";
    overflowWrap?: "break-word";
    wordBreak?: "normal";
    lineBreak?: "auto";
    anchorY?: "CENTER" | "BOTTOM";
};
export type CaptionPlacement = {
    type: "CLIP";
    clipId: number;
    startMs?: number | null;
    endMs?: number | null;
} | {
    type: "TIMELINE";
    startMs: number;
    endMs: number;
};
export type CaptionItem = {
    id: string;
    text: string;
    source: "TEMPLATE" | "USER" | "AUTO";
    role: "SPEECH" | "OVERLAY";
    placement: CaptionPlacement;
    zIndex: number;
    style: CaptionStyle;
};
export type AutoCaptionClipResult = {
    clipId: number;
    status: "PROCESSING" | "COMPLETED" | "NO_SPEECH" | "FAILED";
    text?: string | null;
    utterances?: AutoCaptionUtterance[];
    words?: AutoCaptionWord[];
    needsReview?: boolean | null;
    errorCode?: string | null;
    stale: boolean;
};
export type AutoCaptionUtterance = {
    text?: string | null;
    startMs?: number | null;
    endMs?: number | null;
};
export type AutoCaptionWord = {
    text?: string | null;
    startMs?: number | null;
    endMs?: number | null;
};
export type AutoCaptionJobResponse = {
    jobId: string;
    status: "PROCESSING" | "COMPLETED" | "PARTIAL" | "FAILED" | "STALE";
    attemptNo: number;
    remainingAttempts: number;
    enabled: boolean;
    staleClipIds: number[];
    clips: AutoCaptionClipResult[];
    errorCode?: string | null;
};
export type CropRegion = {
    x: number;
    y: number;
    width: number;
    height: number;
};
export type MediaEdit = {
    start: number;
    duration: number;
    crop: CropRegion;
};
export type CutDurationMode = "RECOMMENDED" | "FORCED";
