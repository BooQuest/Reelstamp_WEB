import type { CaptionItem, CaptionStyle } from './types';
export declare const createCaptionId: () => string;
export declare const clampValue: (value: number, min: number, max: number) => number;
type NormalizeCaptionTextOptions = {
    restoreEscapedNewlines?: boolean;
};
export declare const normalizeCaptionText: (value: string | null | undefined, options?: NormalizeCaptionTextOptions) => string;
export declare const normalizeCaptionStyle: (style: CaptionStyle) => CaptionStyle;
export declare const buildCaptionExportStyle: (style: CaptionStyle) => CaptionStyle;
export declare const buildDraftSignature: (projectName: string, activeClipOrder: number | null, captions: CaptionItem[], captionsEnabled?: boolean) => string;
export declare const normalizeSessionCaptions: (rawCaptions: CaptionItem[] | undefined) => CaptionItem[];
export {};
