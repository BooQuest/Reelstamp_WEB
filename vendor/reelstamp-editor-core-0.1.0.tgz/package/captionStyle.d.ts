import type { CaptionStyle } from "./types";
/** V1's displayed defaults win over unused legacy fields. Never rewrite a stored style on focus. */
export declare function resolveCaptionFontWeight(style: CaptionStyle): number;
export declare const TEXT_COLORS: string[];
export declare function withGalleryStyle(style: CaptionStyle, changes: Partial<CaptionStyle>): CaptionStyle;
export declare function captionTextStyle(style: CaptionStyle): {
    fontFamily: string | undefined;
    fontWeight: number | undefined;
    color: string | undefined;
    textAlign: "left" | "center" | "right" | undefined;
    textShadow: string;
};
export declare function captionBackground(style: CaptionStyle): string;
