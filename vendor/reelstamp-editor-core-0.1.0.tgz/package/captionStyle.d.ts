import type { CaptionStyle } from './types';
export declare const TEXT_COLORS: string[];
export declare function withGalleryStyle(style: CaptionStyle, changes: Partial<CaptionStyle>): CaptionStyle;
export declare function captionTextStyle(style: CaptionStyle): {
    fontFamily?: undefined;
    fontWeight?: undefined;
    color?: undefined;
    textAlign?: undefined;
    textShadow?: undefined;
} | {
    fontFamily: string;
    fontWeight: number;
    color: string;
    textAlign: "left" | "center" | "right";
    textShadow: string;
};
export declare function captionBackground(style: CaptionStyle): string;
